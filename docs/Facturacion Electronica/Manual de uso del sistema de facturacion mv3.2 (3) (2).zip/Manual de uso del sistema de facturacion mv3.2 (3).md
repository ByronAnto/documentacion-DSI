﻿![ref1]![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.002.png)



![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.003.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.004.png)
||
| :- |
||
|<p></p><p></p><p></p>|


![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.005.png)![ref2]<a name="_hlk157423969"></a><a name="_toc446940143"></a>
# Tabla de contenido
[1.	Objetivos del manual	2](#_toc159522879)

[2.	Requisitos del sistema	3](#_toc159522880)

[3.	Cómo iniciar sesión	3](#_toc159522881)

[5.	Pantalla Principal del sistema	6](#_toc159522882)

[Baúl de comprobantes	6](#_toc159522883)

[1)	Criterio de Búsqueda:	6](#_toc159522884)

[2)	Elementos de la interfaz	7](#_toc159522885)

[3)	Empresa:	7](#_toc159522886)

[4)	Marca:	7](#_toc159522887)

[5)	Local:	8](#_toc159522888)

[6)	Mas opciones de búsqueda.	8](#_toc159522889)

[7)	Cantidad:	9](#_toc159522890)

[8)	Numero de comprobante:	9](#_toc159522891)

[9)	Ruc/Cedula:	10](#_toc159522892)

[10)	Clave de acceso	10](#_toc159522893)

[11)	Consulta de facturas	11](#_toc159522894)

[12)	Opciones de descarga de facturas.	11](#_toc159522895)

[Log de errores	13](#_toc159522896)

[1)	Acceder al apartado de consultas	13](#_toc159522897)

[2)	Seleccionar log de errores	13](#_toc159522898)

[3)	Criterio de búsqueda	13](#_toc159522899)

[4)	Empresa	13](#_toc159522900)

[5)	Marca	14](#_toc159522901)

[6)	Local	14](#_toc159522902)

[7)	Opciones de búsqueda	14](#_toc159522903)

[8)	Consulta	15](#_toc159522904)

[9)	Resultado de búsqueda	15](#_toc159522905)

[ANEXOS	15](#_toc159522906)





1. # ` `<a name="_toc159522879"></a>Objetivos del manual
El propósito principal de este manual es proporcionar a los usuarios una guía completa y clara para utilizar de manera efectiva el Sistema de Facturación Electrónica Seed Belling. La documentación busca ser una herramienta valiosa al ofrecer información detallada y recursos visuales, con el objetivo de facilitar una experiencia de usuario positiva y contribuir al éxito en la implementación y utilización eficiente del sistema.
1. # ` `<a name="_toc159522880"></a>Requisitos del sistema
**Requisitos del navegador:**


Selecciona un navegador web actualizado que sea compatible con el sistema. Pueden incluirse opciones como Chrome, Firefox, Edge o Safari. Especifica la versión recomendada para una experiencia óptima.

**Conexión a Internet:**
**

Asegúrate de contar con una conexión a Internet de banda ancha para garantizar una carga rápida de las páginas y una experiencia sin interrupciones.

**Dispositivo Compatible:**


Especifica los dispositivos compatibles, ya sea una computadora de escritorio, portátil, tablet o teléfono inteligente. Puede ser relevante indicar si hay alguna preferencia sobre el sistema operativo.

**Credenciales de Acceso:**


Proporciona información sobre cómo obtener credenciales de acceso, ya sea a través de un proceso de registro en línea o mediante la asignación de cuentas por parte del administrador del sistema.
1. # ` `<a name="_toc159522881"></a>Cómo iniciar sesión

Para comenzar a utilizar el Sistema de Facturación Electrónica Seed Belling, sigue estos pasos para iniciar sesión en tu cuenta:

1. **Acceder a la Página de Inicio de Sesión:**
- Abre tu navegador web preferido (se recomienda Chrome, Firefox, Edge o Safari).



- Ingresa la URL proporcionada para acceder a la página de inicio de sesión del Sistema de Facturación Electrónica Seed Belling.

https://facturasrestaurantes.corlasosa.com/login.jsf

1. **Introducir Credenciales:**
- Ingresa tu nombre de usuario en el campo designado.
- Escribe tu contraseña de acceso. Asegúrate de respetar mayúsculas y minúsculas, ya que la contraseña es sensible a ellas.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.007.png)

1. **Hacer Clic en "Iniciar Sesión":**
- Una vez que hayas ingresado tu nombre de usuario y contraseña, haz clic en el botón "Iniciar Sesión" para acceder al sistema.

  ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.008.png)

1. **Pantalla Principal:**
- ![ref3]Después de iniciar sesión correctamente, serás redirigido a la pantalla principal del sistema, donde podrás acceder a todas las funcionalidades y herramientas disponibles.
1. # <a name="_toc159522882"></a>Pantalla Principal del sistema 
La Pantalla Principal del Sistema de Facturación Electrónica Seed Belling es el centro de operaciones donde los usuarios pueden acceder a todas las funcionalidades y realizar diversas tareas relacionadas con la gestión de facturas y consultas financieras. A continuación, se describen los elementos clave de la Página Principal:

**Menú de Navegación:**

![ref4]
El menú de navegación, ubicado en el lateral o en la parte superior, proporciona acceso rápido a las secciones principales del sistema, como:

1) Administración 
1) Baúl de comprobantes 
1) Consultas 
1) Emisión de comprobantes Manuales
1) Emisión comprobante 
1) Nuevo canal de soporte
1) Ticket estrategit.com
1) Ágil y exacto 
# <a name="_toc159522883"></a>**BAÚL DE COMPROBANTES** 
1) ## <a name="_toc159522884"></a>Criterio de Búsqueda:
![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.011.png)En este menú de búsqueda nos proporcionan un menú de selección tales como: 

1) Empresa
1) Marca
1) Local
1) Punto de emisión
1) No. Comprobante
1) Tipo
1) Fecha de emisión
1) Cantidad
1) Ruc/Cedula
1) Estado
1) Clave de acceso
1) ## <a name="_toc159522885"></a>Elementos de la interfaz
La interfaz del Sistema de Facturación Electrónica Seed Belling ha sido diseñada para ser intuitiva y fácil de usar. Aquí se describen los elementos clave que encontrarás en la interfaz:
1) ## <a name="_toc159522886"></a>Empresa: 
![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.012.png)En este Punto debemos seleccionar la empresa con la cual vamos a trabajar, no olvidemos que el local depende de la marca y la marca depende de la empresa (En este ejemplo usares, INT FOOD SERVICES CORP SA, Servidor del KFC).

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.013.png)

##
##
##
##
1) ## <a name="_toc159522887"></a>Marca:
Aquí debemos elegir la marca con la que vamos a trabajar (Para este ejemplo escogemos KFC).

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.014.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.015.png)



1) ## <a name="_toc159522888"></a>Local:
Sirve para seleccionar el numero del local con el que vamos a trabajar (En este ejemplo constan de 2 partes la letra H es del apartado de Heladerías, la letra K es del apartado de tiendas).

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.016.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.017.png)
1) ## <a name="_toc159522889"></a>Mas opciones de búsqueda.

- **Fecha de emisión desde:**

  En este ámbito de filtra las fechas de las que desea obtener información de las facturas.

  ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.018.png)
7) ## <a name="_toc159522890"></a>Cantidad:
Se puede seleccionar la cantidad de facturas que desea filtrar. ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.019.png)



También se puede filtrar la búsqueda por:

7) ## <a name="_toc159522891"></a>Numero de comprobante:
Para poder filtrar y mostrar el número de comprobante, es necesario ya haber realizado una compra, este es un ejemplo de numero de comprobante.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.020.png)
7) ## <a name="_toc159522892"></a>Ruc/Cedula:
Se puede facilitar la búsqueda ingresando el numero de cedula o ruc, con el que se realizó la transacción.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.021.png)

7) ## <a name="_toc159522893"></a>Clave de acceso
Para poder filtrar la factura con la clave de acceso debemos tomar los numero indicados en la factura. 

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.022.png)

7) ## <a name="_toc159522894"></a>Consulta de facturas
La función de Consulta de Facturas te permite revisar y buscar fácilmente todas las transacciones registradas en el Sistema de Facturación Electrónica Seed Belling. A continuación, se detallan los pasos para realizar una consulta eficaz:

- Debemos elegir a la empresa con la que queremos interactuar.
- Debemos elegir la marca.
- Seleccionaremos el número del local con el que vamos a trabajar.
- Filtra las fechas de las que desea obtener información de las facturas.
- ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.023.png)Seleccionar la cantidad de facturas que desea filtrar.
7) ## <a name="_toc159522895"></a>Opciones de descarga de facturas.
- Para poder acceder a la descarga de la factura debemos seleccionar el apartado del RIDE.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.024.png)

- Seleccionamos el documento que deseamos descargar.
- Una vez ya descargado la factura podemos comprobar los datos de la factura y el precio final de la compra.
- ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.025.png)Una vez cumplido con todos los ámbitos solicitados en el manual podrá acceder a la descarga de las facturas y hacer la revisión de estas.
# <a name="_toc159522896"></a>**LOG DE ERRORES**

En este apartado se puede encontrar información de los comprobantes que no están autorizados o que tengan un error de estructura, para poder acceder a los mismo seguir los siguientes pasos:
1) ## <a name="_toc159522897"></a>Acceder al apartado de consultas
![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.026.png)
1) ## <a name="_toc159522898"></a>Seleccionar log de errores

![ref5]![ref6]








1) ## <a name="_toc159522899"></a>Criterio de búsqueda 
Se abrirá un nuevo criterio de búsqueda.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.029.png)
1) ## <a name="_toc159522900"></a>Empresa 
   En el apartado de empresa de igual manera seleccionamos la marca con la que vamos a trabajar, no olvidemos que **el local depende de la marca y la marca depende de la empresa** (en este caso seleccionaremos Promotora Ecuatoriana de café de Colombia Procafecol S.A,) Este es un servidor de Juan Valdez. 

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.030.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.031.png)

1) ## <a name="_toc159522901"></a>Marca
   El Siguiente paso es seleccionar la marca con la que desea trabajar, en este caso es Juan Valdez.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.032.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.033.png)




1) ## <a name="_toc159522902"></a>Local
   En el apartado de local debemos seleccionar el numero del local del cual vamos a revisar las facturas.

![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.034.png)![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.035.png)
1) ## <a name="_toc159522903"></a>Opciones de búsqueda
   Podemos buscar si existe un error en las facturas por: Ruc/Cedula, Numero de comprobante o Clave de acceso
1) ## <a name="_toc159522904"></a>Consulta
   ![](Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.036.png)En caso de no existir ningún inconveniente con las facturas realizamos la consulta y nos aparecerá un mensaje en la parte superior derecha. 





1) ## <a name="_toc159522905"></a>Resultado de búsqueda  
Como podemos observar hasta el momento no existe ninguna inconsistencia con alguna factura. 
# <a name="_toc159522906"></a>ANEXOS
Recuperar contraseña. 

- Si olvidaste tu contraseña, haz clic en el enlace "¿Olvidó su contraseña?" en la página de inicio de sesión. Sigue las instrucciones proporcionadas para restablecer tu contraseña.

**¡Consejos de Seguridad!**

- No compartas tus credenciales con nadie.
- Cierra la sesión cuando hayas terminado de utilizar el sistema, especialmente en computadoras compartidas.

Recuerda que mantener tus credenciales de inicio de sesión de manera segura es esencial para garantizar la seguridad de tu cuenta y de la información que manejas a través del Sistema de Facturación Electrónica Seed Belling.

15

[ref1]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.001.png
[ref2]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.006.png
[ref3]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.009.png
[ref4]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.010.png
[ref5]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.027.png
[ref6]: Aspose.Words.d8651726-4670-46bc-b7b6-16a25e7bc5e1.028.png
